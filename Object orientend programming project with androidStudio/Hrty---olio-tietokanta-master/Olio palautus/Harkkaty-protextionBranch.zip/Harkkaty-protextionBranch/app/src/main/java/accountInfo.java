import java.util.ArrayList;

public class accountInfo {
    private ArrayList<account> ACInfoList;

}
