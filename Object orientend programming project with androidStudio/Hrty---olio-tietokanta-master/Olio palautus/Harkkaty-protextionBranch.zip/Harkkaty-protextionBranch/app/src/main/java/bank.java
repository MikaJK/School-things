import java.util.Date;

public class bank {



    public void makeAccountDetails(String Fname, String Lname, Date birth, String Country, String phoneNumber, String email){

    }

    public void makeUser(){

    }
}
