import java.util.Date;

public class user {
    private String name;
    private String email;
    private String userID;
    private String phoneNumberM;
    private String address;
    private int age;
    private Date born;

    public user(){
        name="";
        email = "";
        userID = "";
        phoneNumberM = "";
        address = "";
        age = 0;
        born = null;

    }


}
