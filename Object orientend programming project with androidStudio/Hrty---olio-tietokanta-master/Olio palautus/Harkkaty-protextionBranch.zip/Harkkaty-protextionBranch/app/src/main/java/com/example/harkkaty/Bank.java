package com.example.harkkaty;

//doesn't have anything in it because the bank side of the app isin't used for anything
public class Bank {
}
